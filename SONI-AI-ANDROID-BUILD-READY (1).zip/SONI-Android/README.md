# SONI AI Android

Build-ready Android project for the SONI AI mobile assistant.

## Features
- SONI voice assistant UI in a WebView
- Android SpeechRecognizer voice input
- Android Text-to-Speech output
- Groq API with Gemini fallback
- API keys stored locally on the device
- YouTube search command
- Local memory and profile settings
- Android 8.0+ (API 26+) support

## Build
This project includes a Gradle bootstrap wrapper (`gradlew` / `gradlew.bat`). It downloads Gradle 8.11.1 automatically when needed.

### Windows
```powershell
.\\gradlew.bat assembleDebug
```

### Linux/macOS
```bash
./gradlew assembleDebug
```

The installable debug APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

## Bitrise
The repository includes `bitrise.yml`. Connect the repository to Bitrise and run the `primary` workflow. It builds the `app` module as a debug APK and uploads the artifact.

## First launch
Open Settings (gear) > AI API Configuration and enter the user's own Groq and/or Gemini API key. Keys are stored locally and are not bundled into the APK.

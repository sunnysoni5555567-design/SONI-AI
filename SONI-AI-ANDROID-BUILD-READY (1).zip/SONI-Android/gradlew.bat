@echo off
setlocal
set "GRADLE_VERSION=8.11.1"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME=%GRADLE_USER_HOME%\soni-gradle\%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
set "TMP=%TEMP%\soni-gradle-%GRADLE_VERSION%.zip"
where curl.exe >nul 2>nul
if %errorlevel%==0 (
  curl.exe -fL --retry 3 -o "%TMP%" "https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TMP%'"
)
if not exist "%GRADLE_HOME%" mkdir "%GRADLE_HOME%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%TMP%' '%GRADLE_HOME%_extract'"
move /Y "%GRADLE_HOME%_extract\gradle-%GRADLE_VERSION%\*" "%GRADLE_HOME%" >nul
rmdir /S /Q "%GRADLE_HOME%_extract"
del /Q "%TMP%" >nul 2>nul
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal

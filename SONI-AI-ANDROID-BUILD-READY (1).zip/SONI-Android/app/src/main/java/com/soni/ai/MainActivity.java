package com.soni.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView web; SharedPreferences prefs; TextToSpeech tts; SpeechRecognizer recognizer;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("soni",0); setupTts(); setupWeb();}
    void setupTts(){tts=new TextToSpeech(this, s->{ if(s==TextToSpeech.SUCCESS){tts.setLanguage(Locale.getDefault());}});}
    void setupWeb(){
        web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(),"Android"); web.loadUrl("file:///android_asset/index.html");
    }
    void voice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},42); return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){web.evaluateJavascript("window.nativeVoiceError('Speech recognition is not available on this phone.')",null);return;}
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
            public void onError(int e){web.evaluateJavascript("window.nativeVoiceError('Voice recognition error. Please try again.')",null);}
            public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()){String q=JSONObject.quote(a.get(0)); web.evaluateJavascript("window.onNativeVoice("+q+")",null);}}
            public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"SONI ko bolo..."); recognizer.startListening(i);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==42&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) voice();}
    @Override public void onDestroy(){if(recognizer!=null)recognizer.destroy(); if(tts!=null)tts.shutdown(); super.onDestroy();}
    public class Bridge {
        @JavascriptInterface public String getKeys(){try{JSONObject o=new JSONObject();o.put("groq",prefs.getString("groq",""));o.put("gemini",prefs.getString("gemini",""));o.put("groqModel",prefs.getString("groqModel","llama-3.3-70b-versatile"));o.put("geminiModel",prefs.getString("geminiModel","gemini-2.5-flash"));return o.toString();}catch(Exception e){return "{}";}}
        @JavascriptInterface public void saveKeys(String groq,String gemini,String groqModel,String geminiModel){prefs.edit().putString("groq",groq==null?"":groq.trim()).putString("gemini",gemini==null?"":gemini.trim()).putString("groqModel",groqModel==null?"llama-3.3-70b-versatile":groqModel.trim()).putString("geminiModel",geminiModel==null?"gemini-2.5-flash":geminiModel.trim()).apply();}
        @JavascriptInterface public void speak(String text){if(tts!=null){tts.stop();tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"soni");}}
        @JavascriptInterface public void startVoice(){voice();}
        @JavascriptInterface public void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){}}
        @JavascriptInterface public void openYoutube(String q){openUrl("https://www.youtube.com/results?search_query="+Uri.encode(q));}
        @JavascriptInterface public String getNetwork(){return "ONLINE";}
    }
}

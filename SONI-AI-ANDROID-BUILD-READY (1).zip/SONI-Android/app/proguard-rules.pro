# SONI AI - no custom ProGuard rules required for debug builds.

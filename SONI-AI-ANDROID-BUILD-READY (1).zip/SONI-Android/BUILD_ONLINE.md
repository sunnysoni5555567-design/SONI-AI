# Build SONI AI online

## Bitrise
1. Push the contents of this folder to a GitHub repository.
2. In Bitrise choose **Create New App** and connect the GitHub repository.
3. Choose Android.
4. If Bitrise asks for a workflow, use the included `bitrise.yml` or configure:
   - Module: `app`
   - Variant: `debug`
   - Build type: `apk`
   - Java: 17
5. Start the build.
6. Download the APK from the build Artifacts.

## Local Windows
Run:
    .\\gradlew.bat assembleDebug

APK:
    app\\build\\outputs\\apk\\debug\\app-debug.apk
